package Progetto_LPO.parser;

import Progetto_LPO.parser.ast.Prog;

public interface Parser extends AutoCloseable {

	Prog parseProg() throws ParserException;

}
