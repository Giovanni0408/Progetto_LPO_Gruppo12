package Progetto_LPO.parser.ast;

public interface VarIdent extends Exp {
	String getName();
}
