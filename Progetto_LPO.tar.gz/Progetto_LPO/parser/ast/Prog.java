package Progetto_LPO.parser.ast;

public interface Prog extends AST {
}
