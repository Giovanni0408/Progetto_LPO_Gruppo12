package Progetto_LPO.parser.ast;

public interface Stmt extends AST {
}
