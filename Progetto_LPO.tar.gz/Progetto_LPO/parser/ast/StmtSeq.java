package Progetto_LPO.parser.ast;

public interface StmtSeq extends AST {
}
