package Progetto_LPO.parser.ast;

import Progetto_LPO.visitors.Visitor;

public interface AST {
	<T> T accept(Visitor<T> visitor);
}
