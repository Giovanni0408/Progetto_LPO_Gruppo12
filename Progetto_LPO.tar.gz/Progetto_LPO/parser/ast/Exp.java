package Progetto_LPO.parser.ast;

public interface Exp extends AST {
}
