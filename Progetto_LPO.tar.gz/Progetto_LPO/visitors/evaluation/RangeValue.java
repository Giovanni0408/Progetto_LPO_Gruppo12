package Progetto_LPO.visitors.evaluation;

import static java.util.Objects.requireNonNull;
import static java.util.Objects.hash;
import java.util.Iterator;
import java.lang.Iterable;
import java.util.NoSuchElementException;

public class RangeValue implements Value, Iterator<Integer>, Iterable<Integer> {

	private int start;
	private int end;
	
	public RangeValue(int start, int end) {
		this.start = requireNonNull(start);
		this.end = requireNonNull(end);
	}
	
	public RangeValue(RangeValue range) {
		this.start = requireNonNull(range.start);
		this.end = requireNonNull(range.end);
	}

	public IntValue getStart() {
		return new IntValue(start);
	}

	public IntValue getEnd() {
		return new IntValue(end);
	}
	
	public boolean hasNext() {
		return start != end;
	}
	
	@Override
	public Integer next() {
		if(!hasNext()) throw new NoSuchElementException();
		int res;
		res = start;
		if(start < end) start++;
		else start --;
		return res;
	}

	@Override public Iterator<Integer> iterator() {
		return this;
	}
	
	@Override
	public RangeValue toRange() {
		return this;
	}

	@Override
	public String toString() {
		return "[" + start + ":" + end + "]";
	}

	@Override
	public int hashCode() {
		return hash(start, end);
	}

	@Override
	public final boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof RangeValue))
			return false;
		var op = (RangeValue) obj;
		return (!this.hasNext() && !op.hasNext()) || (start == op.start && end == op.end);
	}
}
