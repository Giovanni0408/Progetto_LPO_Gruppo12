package Progetto_LPO.visitors.typechecking;

public enum PrimType implements Type {
	BOOL, INT, RANGE;
}
